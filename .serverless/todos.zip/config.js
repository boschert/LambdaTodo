var env = {};
env.AUTH0_SECRET='3YzsJaEenLteenAlBc0T10hRcl7CH23x8UIxJjYEoK0YWmqYsN5UHPiaZo_SIFhM';
env.DOMAIN = 'saruvia.auth0.com';
module.exports = env;